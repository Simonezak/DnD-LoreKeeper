package pjdm.pjdm2022.dungeonsdragons_lorekeeper;

import static android.content.ContentValues.TAG;

import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import pjdm.pjdm2022.dungeonsdragons_lorekeeper.databinding.ActivityToolbarscreenBinding;

public class ToolbarscreenActivity extends AppCompatActivity  {

    ActivityToolbarscreenBinding binding; //la classe ha lo stesso nome del fragment a cui devi attaccare quello che devi attaccate

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityToolbarscreenBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        replaceFragment(new HomeFragment());

        binding.bottomNavigationView.setOnItemSelectedListener(item2 -> {
            int itemId2 = item2.getItemId();

            if (itemId2 == R.id.btHome) {
                replaceFragment(new HomeFragment());
            } else if (itemId2 == R.id.btSearch) {
                replaceFragment(new SearchFragment());
            } else if (itemId2 == R.id.btProfile) {
                replaceFragment(new ProfileFragment());
            }

            return true;
        });

    }

    private void replaceFragment(Fragment fragment){

        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.fragmentContainerViewToolbarScreen,fragment);
        fragmentTransaction.commit();
    }


}