package pjdm.pjdm2022.dungeonsdragons_lorekeeper;

import static android.content.ContentValues.TAG;

import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import pjdm.pjdm2022.dungeonsdragons_lorekeeper.databinding.ActivityToolbarscreenBinding;

public class ToolbarscreenActivity extends AppCompatActivity  {

    ActivityToolbarscreenBinding binding; //la classe ha lo stesso nome del fragment a cui devi attaccare quello che devi attaccate
    HomeAdapter homeAdapter;
    RecyclerView rv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityToolbarscreenBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        Toolbar toolbar = findViewById(R.id.topToolbar);
        setSupportActionBar(toolbar); // fa diventare la mia toolbar personalizzata la toolbar di default


        binding.topToolbar.setOnMenuItemClickListener(item -> {
            int itemId = item.getItemId();

            if (itemId == R.id.btAddCampaign) {
                    addGroup();
            } else if (itemId == R.id.btLogout) {
                    Toast.makeText(getApplicationContext(), "Simone puzza",Toast.LENGTH_SHORT).show();
            }

            return true;
        });

        binding.bottomNavigationView.setOnItemSelectedListener(item2 -> {
            int itemId2 = item2.getItemId();

            if (itemId2 == R.id.btHome) {
                replaceFragment(new HomeFragment());
            } else if (itemId2 == R.id.btSearch) {
                replaceFragment(new SearchFragment());
            } else if (itemId2 == R.id.btProfile) {
                replaceFragment(new ProfileFragment());
            }

            return true;
        });

        ItemTouchHelper ith = new ItemTouchHelper(new ItemTouchHelper.SimpleCallback(ItemTouchHelper.UP | ItemTouchHelper.DOWN,0) {
            @Override
            public boolean onMove(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder, @NonNull RecyclerView.ViewHolder target) {
                int from = viewHolder.getAdapterPosition();
                int to = target.getAdapterPosition();
                homeAdapter.move(from, to);
                return true;
            }
            @Override
            public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int direction) {
                Log.d(TAG, "onSwiped() called with: viewHolder = [" + viewHolder + "], direction = [" + direction + "]");

                /* mi restituisce la posizione in cui sono nell'adapter*/
                int position = viewHolder.getAdapterPosition();

                homeAdapter.remove(position);
                }
            });
        ith.attachToRecyclerView(rv);

    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        boolean result = super.onPrepareOptionsMenu(menu);
        Fragment currentFragment = getSupportFragmentManager().findFragmentById(R.id.coordinatorLayout1);
        if(currentFragment instanceof HomeFragment) {
            menu.findItem(R.id.btAddCampaign).setVisible(true);
            menu.findItem(R.id.btLogout).setVisible(false);
        } else if (currentFragment instanceof  SearchFragment ) {
            menu.findItem(R.id.btAddCampaign).setVisible(false);
            menu.findItem(R.id.btLogout).setVisible(false);
        } else if (currentFragment instanceof  ProfileFragment ) {
            menu.findItem(R.id.btAddCampaign).setVisible(false);
            menu.findItem(R.id.btLogout).setVisible(true);
        }

        return result;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.top_nav_toolbar, menu);

        return true;
    }


    private void addGroup() {

        rv = findViewById(R.id.rvHome);
        homeAdapter = new HomeAdapter(this);
        rv.setLayoutManager(new LinearLayoutManager(this));
        rv.setAdapter(homeAdapter);

        Log.d(TAG, "addGroup: called");
        AlertDialog.Builder builder = new AlertDialog.Builder(this,R.style.AlertDialogTheme);

        View dialogView = LayoutInflater.from(this).inflate(R.layout.add_dialog, findViewById(android.R.id.content), false);

        final EditText etNomeCampagna = dialogView.findViewById(R.id.etNomeCampagna);
        final EditText etDescrizione = dialogView.findViewById(R.id.etDescrizione);
        final SeekBar sbNumMaxGiocatori = dialogView.findViewById(R.id.sbNumMaxGiocatori);

        builder.setTitle("Crea Campagna");
        builder.setView(dialogView);

        sbNumMaxGiocatori.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {

            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                int seekBarValue = seekBar.getProgress();
                String seekBarValueString = String.valueOf(seekBarValue);
                Toast.makeText(getApplicationContext(), "Your current value: " + seekBarValueString, Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                int seekBarValue = seekBar.getProgress();
                String seekBarValueString = String.valueOf(seekBarValue);
                Toast.makeText(getApplicationContext(), "Your new value: " + seekBarValueString, Toast.LENGTH_SHORT).show();
            }
        });


        builder.setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.dismiss();

                String nomeCampagna = etNomeCampagna.getText().toString();
                String descrizione = etDescrizione.getText().toString();
                int numMaxGiocatori = sbNumMaxGiocatori.getProgress();

                homeAdapter.addItem(nomeCampagna,descrizione,"BAU",numMaxGiocatori);

                Log.d(TAG, "onClickPOSITIVEBUTTON() called");
            }
        });

        builder.setNegativeButton(android.R.string.cancel,new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.dismiss();

            }
        });

        builder.show();


    }

    private void replaceFragment(Fragment fragment){

        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.coordinatorLayout1,fragment);
        fragmentTransaction.commit();
    }


}