package pjdm.pjdm2022.dungeonsdragons_lorekeeper;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;


public class SharedViewModel extends ViewModel {
    private final MutableLiveData<String> selected = new MutableLiveData<String>();
    private String username;
    private HomeElement homeElement;

    //Questa classe viene utilizzata per condividere le varie informazioni tra i fragment
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public void setSelected(String item) {
        selected.setValue(item);
    }

    public LiveData<String> getSelected() {
        return selected;
    }

    public void setHomeElement(HomeElement homeElement){
        this.homeElement = homeElement;
    }

    public HomeElement getHomeElement(){
        return homeElement;
    }

}