package pjdm.pjdm2022.dungeonsdragons_lorekeeper;

import static android.content.ContentValues.TAG;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.Collections;

import pjdm.pjdm2022.dungeonsdragons_lorekeeper.databinding.ActivityToolbarscreenBinding;

public class HomeAdapter extends RecyclerView.Adapter<HomeAdapter.CAViewHolder>{


    private ArrayList<HomeElement> datiCampagne;
    //private HomeFragment homeFragment;
    private FragmentActivity fragmentActivity;
    private ActivityToolbarscreenBinding binding;
    private LayoutInflater inflater;
    private Context context;

    public HomeAdapter(Context context) {
        this.inflater = LayoutInflater.from(context);
        datiCampagne = new ArrayList<HomeElement>();

        datiCampagne.add(new HomeElement("Le Ceneri di Icadia", "Smemu1p", 5));
        datiCampagne.add(new HomeElement("L'Ultimo Santuario", "Uqia", 6));
        datiCampagne.add(new HomeElement("Viaggio nelle Terre Dimenticate", "Fuyu", 3));

    }

    @NonNull
    @Override
    public CAViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = inflater.inflate(R.layout.campaign_item,parent,false);
        CAViewHolder vh = new CAViewHolder(v);
        context = parent.getContext();
        return vh;
    }

    @Override
    public void onBindViewHolder(@NonNull CAViewHolder holder, int position) {
        holder.tvRowNomeCampagna.setText(datiCampagne.get(position).getNomeCampagna());
        holder.tvDM.setText("DM: " + datiCampagne.get(position).getUsernameDM());
        holder.tvRowMaxGiocatori.setText("Max Giocatori: " + Integer.toString(datiCampagne.get(position).getNumMaxGiocatori()));
    }

    @Override
    public int getItemCount() {
        return datiCampagne.size();
    }

    /* Facciamo si che Lista Holder è anche un onClickListener e l'onClick specifico sull'ibSel
     * quindi dobbiamo agganciare su ibSel l'onClick. Quando viene cliccato l'elemento questo metodo
     * viene chiamato perchè il holder è anche onCliclListener*/

    class CAViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        TextView tvRowNomeCampagna;
        TextView tvRowMaxGiocatori;
        TextView tvDM;
        CardView cardView;

        public CAViewHolder(@NonNull View itemView) {
            super(itemView);
            tvRowNomeCampagna = itemView.findViewById(R.id.tvRowNomeCampagna);
            tvRowMaxGiocatori = itemView.findViewById(R.id.tvRowMaxGiocatori);
            tvDM = itemView.findViewById(R.id.tvDM);

            cardView = itemView.findViewById(R.id.cvCampaignItem);

            cardView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int pos = getAdapterPosition();
                    Log.d(TAG, "onClick: Cliccato Carta");
                    //SharedViewModel sharedViewModel = new ViewModelProvider(fragmentActivity).get(SharedViewModel.class);
                    //sharedViewModel.setHomeElement(datiCampagne.get(pos));
                    //NavHostFragment.findNavController(studentGroupFragment).navigate(R.id.action_studentGroupFragment_to_documentFragment);
                    //TODO
                }
            });

            /*
            cardView.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View v) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(fragmentActivity, R.style.AlertDialogTheme);
                    View rootView = LayoutInflater.from(fragmentActivity).inflate(R.layout.popup_description,
                            binding.getRoot().findViewById(android.R.id.content), false);

                    final TextView tvDescription = rootView.findViewById(R.id.tvPopupDescrizione);
                    tvDescription.setText(datiCampagne.get(getAdapterPosition()).getDescrizione());

                    builder.setTitle("Descrizione gruppo:");
                    builder.setView(rootView);

                    builder.setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            dialogInterface.dismiss();
                        }
                    });
                    builder.show();
                    return false;
                }
            });*/

        }

        @Override
        public void onClick(View view) {

            /* l'holder ha in se la sua posizione dentro l'adapter. è comodo avere un holder perchè
             * ha tutte le informazioni su dove sta sulla lista, mi prendo la sua posizione e gli
             * cambio lo stato. */

            int pos = getAdapterPosition();
            datiCampagne.get(pos);
            notifyDataSetChanged();

            //TODO
        }
    }

    public void addItem(String nomeCampagna, String descrizione, String usernameDM, int numMaxGiocatori){
        datiCampagne.add(new HomeElement(nomeCampagna, descrizione, usernameDM, numMaxGiocatori));
        notifyDataSetChanged();
    }
    
    public void move(int from, int to) {
        Collections.swap(datiCampagne, from, to);
        notifyItemMoved(from, to);
    }

    //public void remove(int position) {
        //studentGroups.remove(studentGroups.get(position));
        //notifyDataSetChanged();
        //TODO
    //}

}