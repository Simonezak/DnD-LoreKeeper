package pjdm.pjdm2022.dungeonsdragons_lorekeeper;

import static android.content.ContentValues.TAG;

import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.Toolbar;

import pjdm.pjdm2022.dungeonsdragons_lorekeeper.databinding.FragmentHomeBinding;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link HomeFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class HomeFragment extends Fragment {

    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";
    private String mParam1;
    private String mParam2;
    private FragmentHomeBinding binding;

    HomeAdapter homeAdapter;
    RecyclerView rv;

    public HomeFragment() {
    }

    public static HomeFragment newInstance(String param1, String param2) {
        HomeFragment fragment = new HomeFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
        OnBackPressedCallback callback = new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {

            }
        };
        requireActivity().getOnBackPressedDispatcher().addCallback(this, callback);

    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        binding = FragmentHomeBinding.inflate(inflater,container,false);

        homeAdapter = new HomeAdapter(getContext());
        rv = binding.rvHome;
        rv.setLayoutManager(new LinearLayoutManager(getContext()));
        rv.setHasFixedSize(true);
        rv.setAdapter(homeAdapter);


        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        Log.d(TAG, "onViewCreated() called with: view = [" + view + "], savedInstanceState = [" + savedInstanceState + "]");
        super.onViewCreated(view, savedInstanceState);

        binding.toolbarHome.setTitle("Le Mie Campagne");
        binding.toolbarHome.getMenu().findItem(R.id.btSearchCampaign).setVisible(false);
        binding.toolbarHome.getMenu().findItem(R.id.btLogout).setVisible(false);


        binding.toolbarHome.setOnMenuItemClickListener(item -> {
            int itemId = item.getItemId();
            if (itemId == R.id.btAddCampaign) {
                addGroup();
            }
            return true;
        });

        ItemTouchHelper ith = new ItemTouchHelper(new ItemTouchHelper.SimpleCallback(ItemTouchHelper.UP | ItemTouchHelper.DOWN,0) {
            @Override
            public boolean onMove(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder, @NonNull RecyclerView.ViewHolder target) {
                int from = viewHolder.getAdapterPosition();
                int to = target.getAdapterPosition();
                homeAdapter.move(from, to);
                return true;
            }
            @Override
            public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int direction) {

            }
        });
        ith.attachToRecyclerView(rv);


    }


    private void addGroup() {

        Log.d(TAG, "addGroup: called");
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity(),R.style.AlertDialogTheme);

        View dialogView = LayoutInflater.from(getActivity()).inflate(R.layout.add_dialog, binding.getRoot().findViewById(android.R.id.content), false);

        final EditText etNomeCampagna = dialogView.findViewById(R.id.etNomeCampagna);
        final EditText etDescrizione = dialogView.findViewById(R.id.etDescrizione);
        final SeekBar sbNumMaxGiocatori = dialogView.findViewById(R.id.sbNumMaxGiocatori);

        builder.setTitle("Crea Campagna");
        builder.setView(dialogView);

        sbNumMaxGiocatori.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {

            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                int seekBarValue = seekBar.getProgress();
                String seekBarValueString = String.valueOf(seekBarValue);
                Toast.makeText(getActivity(), "Your current value: " + seekBarValueString, Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                int seekBarValue = seekBar.getProgress();
                String seekBarValueString = String.valueOf(seekBarValue);
                Toast.makeText(getActivity(), "Your new value: " + seekBarValueString, Toast.LENGTH_SHORT).show();
            }
        });


        builder.setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.dismiss();

                String nomeCampagna = etNomeCampagna.getText().toString();
                String descrizione = etDescrizione.getText().toString();
                int numMaxGiocatori = sbNumMaxGiocatori.getProgress();

                homeAdapter.addItem(nomeCampagna,descrizione,"BAU",numMaxGiocatori);

                Log.d(TAG, "onClickPOSITIVEBUTTON() called");
            }
        });

        builder.setNegativeButton(android.R.string.cancel,new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.dismiss();

            }
        });

        builder.show();


    }




    @Override
    public void onStop() {
        super.onStop();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }

}