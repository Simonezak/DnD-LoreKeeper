package pjdm.pjdm2022.dungeonsdragons_lorekeeper;

public class HomeElement {

    private String nomeCampagna;
    private String descrizione;
    private String usernameDM;
    private int numMaxGiocatori;


    public HomeElement(String nomeCampagna, String descrizione, String usernameDM, int numMaxGiocatori) {
        this.nomeCampagna = nomeCampagna;
        this.descrizione = descrizione;
        this.usernameDM = usernameDM;
        this.numMaxGiocatori = numMaxGiocatori;
    }

    public HomeElement(String nomeCampagna, String usernameDM, int numMaxGiocatori) {
        this.nomeCampagna = nomeCampagna;
        this.descrizione = "";
        this.usernameDM = usernameDM;
        this.numMaxGiocatori = numMaxGiocatori;
    }

    public String getNomeCampagna() {
        return nomeCampagna;
    }

    public String getDescrizione() {
        return descrizione;
    }

    public String getUsernameDM() {
        return usernameDM;
    }

    public int getNumMaxGiocatori() {
        return numMaxGiocatori;
    }


}
